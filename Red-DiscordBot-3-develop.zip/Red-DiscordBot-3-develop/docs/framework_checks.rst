.. _checks:

========================
Command Check Decorators
========================

The following are all decorators for commands, which add restrictions to where and when they can be
run.

.. automodule:: redbot.core.checks
    :members:
