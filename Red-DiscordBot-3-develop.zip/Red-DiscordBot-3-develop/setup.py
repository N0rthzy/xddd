from setuptools import setup

# Metadata and options defined in setup.cfg
setup()
